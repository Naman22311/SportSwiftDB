create definer = root@localhost trigger update_blocked_status
    before update
    on customer
    for each row
BEGIN
    IF NEW.failed_attempts >= 3 THEN
        INSERT INTO check_blocked (customer_id, blocked) VALUES (NEW.Customer_ID, true);
    END IF;
END;

