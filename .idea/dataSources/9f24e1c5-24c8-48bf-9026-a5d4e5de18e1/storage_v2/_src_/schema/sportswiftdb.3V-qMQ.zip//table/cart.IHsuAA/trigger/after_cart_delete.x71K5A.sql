create definer = root@localhost trigger after_cart_delete
    after delete
    on cart
    for each row
BEGIN
    INSERT INTO Orders (Customer_ID, Product_ID) VALUES (OLD.Customer_ID, OLD.Product_ID);
END;

